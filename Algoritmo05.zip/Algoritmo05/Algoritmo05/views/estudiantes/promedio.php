

<?php
echo  "Hola  ". $estudiante->getNombre(). " tu promedio es: " . $estudiante->promedio();
?>