<?php

echo "Hola " . $respuesta->getNombre() . " el resultado de tu prueba fue: " . $respuesta->darResultado();